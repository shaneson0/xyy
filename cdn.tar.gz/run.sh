#!/bin/bash
./build.sh
cd bin 
#./cdn ../case_example/case0.txt ../case_example/result0.txt
########./cdn ../case_example/case1.txt ../case_example/result1.txt
########./cdn ../case_example/case2.txt ../case_example/result2.txt
########./cdn ../case_example/case3.txt ../case_example/result3.txt
########./cdn ../case_example/case4.txt ../case_example/result4.txt
########./cdn ../case_example/ywz0.txt ../case_example/ywz1.txt

########./cdn ../case_example/second/0/case0.txt ../case_example/second/0/result0.txt
########./cdn ../case_example/second/0/case1.txt ../case_example/second/0/result1.txt
########./cdn ../case_example/second/0/case2.txt ../case_example/second/0/result2.txt
########./cdn ../case_example/second/0/case3.txt ../case_example/second/0/result3.txt
########./cdn ../case_example/second/0/case4.txt ../case_example/second/0/result4.txt
########./cdn ../case_example/second/0/case5.txt ../case_example/second/0/result5.txt
########./cdn ../case_example/second/0/case6.txt ../case_example/second/0/result6.txt
########./cdn ../case_example/second/0/case7.txt ../case_example/second/0/result7.txt
########./cdn ../case_example/second/0/case8.txt ../case_example/second/0/result8.txt

########./cdn ../case_example/second/1/case0.txt ../case_example/second/1/result0.txt
########./cdn ../case_example/second/1/case1.txt ../case_example/second/1/result1.txt
########./cdn ../case_example/second/1/case2.txt ../case_example/second/1/result2.txt
########./cdn ../case_example/second/1/case3.txt ../case_example/second/1/result3.txt
########./cdn ../case_example/second/1/case4.txt ../case_example/second/1/result4.txt
########./cdn ../case_example/second/1/case5.txt ../case_example/second/1/result5.txt
########./cdn ../case_example/second/1/case6.txt ../case_example/second/1/result6.txt
########./cdn ../case_example/second/1/case7.txt ../case_example/second/1/result7.txt
########./cdn ../case_example/second/1/case8.txt ../case_example/second/1/result8.txt

########./cdn ../case_example/second/2/case0.txt ../case_example/second/2/result0.txt
########./cdn ../case_example/second/2/case1.txt ../case_example/second/2/result1.txt
########./cdn ../case_example/second/2/case2.txt ../case_example/second/2/result2.txt
########./cdn ../case_example/second/2/case3.txt ../case_example/second/2/result3.txt
########./cdn ../case_example/second/2/case4.txt ../case_example/second/2/result4.txt
########./cdn ../case_example/second/2/case5.txt ../case_example/second/2/result5.txt
########./cdn ../case_example/second/2/case6.txt ../case_example/second/2/result6.txt
########./cdn ../case_example/second/2/case7.txt ../case_example/second/2/result7.txt
########./cdn ../case_example/second/2/case8.txt ../case_example/second/2/result8.txt

./cdn ../case_example/second/0/case0.txt ../case_example/shanxuan/0/result0.txt
# ./cdn ../case_example/second/1/case0.txt ../case_example/shanxuan/1/result0.txt
# ./cdn ../case_example/second/2/case0.txt ../case_example/shanxuan/2/result0.txt
